const categories = {
  'Online Mentors': {
    'Subject-specific Tutors': [
      { name: 'Khan Academy', link: 'https://www.khanacademy.org/' },
      { name: 'Chegg Tutors', link: 'https://www.chegg.com/tutors/' },
      { name: 'Varsity Tutors', link: 'https://www.varsitytutors.com/' },
      { name: 'Wyzant', link: 'https://www.wyzant.com/' },
      { name: 'Tutor.com', link: 'https://www.tutor.com/' }
    ],
    'Academic Coaches': [
      { name: 'Smarthinking', link: 'https://www.pearson.com/us/higher-education/products-services-institutions/smarthinking.html' },
      { name: 'Grade Potential', link: 'https://www.gradepotentialtutoring.com/' },
      { name: 'Sylvan Learning', link: 'https://www.sylvanlearning.com/' },
      { name: 'Huntington Learning Center', link: 'https://huntingtonhelps.com/' },
      { name: 'Club Z! Tutoring', link: 'https://clubztutoring.com/' }
    ],
    'Career Mentors': [
      { name: 'The Muse', link: 'https://www.themuse.com/advice' },
      { name: 'Monster Career Advice', link: 'https://www.monster.com/career-advice' },
      { name: 'LinkedIn Learning', link: 'https://www.linkedin.com/learning/' },
      { name: 'National Career Fairs', link: 'https://www.nationalcareerfairs.com/' },
      { name: 'Forbes Coaches Council', link: 'https://www.forbes.com/coaches-council/' }
    ],
    'Peer Mentors': [
      { name: 'StudentMentor.org', link: 'https://www.studentmentor.org/' },
      { name: 'iCouldBe', link: 'https://icouldbe.org/' },
      { name: 'MentorNet', link: 'https://mentornet.org/' },
      { name: 'iMentor', link: 'https://www.imentor.org/' },
      { name: 'National Mentoring Resource Center', link: 'https://nationalmentoringresourcecenter.org/' }
    ],
    'Special Needs Tutors': [
      { name: 'Learning Ally', link: 'https://learningally.org/' },
      { name: 'Noodle', link: 'https://www.noodle.com/' },
      { name: 'Understood', link: 'https://www.understood.org/' },
      { name: 'Autism Speaks', link: 'https://www.autismspeaks.org/' },
      { name: 'Learning Disabilities Association of America', link: 'https://ldaamerica.org/' }
    ],
    'Test Prep Coaches': [
      { name: 'Princeton Review', link: 'https://www.princetonreview.com/' },
      { name: 'Kaplan Test Prep', link: 'https://www.kaptest.com/' },
      { name: 'Magoosh', link: 'https://www.magoosh.com/' },
      { name: 'PrepScholar', link: 'https://www.prepscholar.com/' },
      { name: 'Manhattan Prep', link: 'https://www.manhattanprep.com/' }
    ],
    'Life Coaches': [
      { name: 'Coach.me', link: 'https://www.coach.me/' },
      { name: 'Noomii', link: 'https://www.noomii.com/' },
      { name: 'BetterHelp', link: 'https://www.betterhelp.com/' },
      { name: 'Life Coach Directory', link: 'https://www.lifecoach-directory.org.uk/' },
      { name: 'International Coach Federation', link: 'https://coachfederation.org/' }
    ],
    'College Admission Counselors': [
      { name: 'Common App', link: 'https://www.commonapp.org/' },
      { name: 'College Board', link: 'https://www.collegeboard.org/' },
      { name: 'NACAC College Fairs', link: 'https://www.nacacfairs.org/' },
      { name: 'American College Counseling Association', link: 'https://www.accounseling.org/' },
      { name: 'National Association for College Admission Counseling', link: 'https://www.nacacnet.org/' }
    ],
    'Language Tutors': [
      { name: 'italki', link: 'https://www.italki.com/' },
      { name: 'Verbling', link: 'https://www.verbling.com/' },
      { name: 'Duolingo', link: 'https://www.duolingo.com/' },
      { name: 'Rosetta Stone', link: 'https://www.rosettastone.com/' },
      { name: 'FluentU', link: 'https://www.fluentu.com/' }
    ],
    'Tech and Coding Mentors': [
      { name: 'Codecademy', link: 'https://www.codecademy.com/' },
      { name: 'freeCodeCamp', link: 'https://www.freecodecamp.org/' },
      { name: 'Udacity', link: 'https://www.udacity.com/' },
      { name: 'Pluralsight', link: 'https://www.pluralsight.com/' },
      { name: 'Treehouse', link: 'https://teamtreehouse.com/' }
    ],
    'Creative Art Mentors': [
      { name: 'CreativeLive', link: 'https://www.creativelive.com/' },
      { name: 'Skillshare', link: 'https://www.skillshare.com/' },
      { name: 'MasterClass', link: 'https://www.masterclass.com/' },
      { name: 'Udemy', link: 'https://www.udemy.com/' },
      { name: 'Kadenze', link: 'https://www.kadenze.com/' }
    ]
  },
  'Free Learning Materials': {
    'Open Courseware': [
      { name: 'MIT OpenCourseWare', link: 'https://ocw.mit.edu/index.htm' },
      { name: 'Coursera', link: 'https://www.coursera.org/' },
      { name: 'edX', link: 'https://www.edx.org/' },
      { name: 'OpenLearn', link: 'https://www.open.edu/openlearn/' },
      { name: 'FutureLearn', link: 'https://www.futurelearn.com/' }
    ],
    'E-Books': [
      { name: 'Project Gutenberg', link: 'https://www.gutenberg.org/' },
      { name: 'Open Library', link: 'https://openlibrary.org/' },
      { name: 'Bookboon', link: 'https://bookboon.com/' },
      { name: 'ManyBooks', link: 'https://manybooks.net/' },
      { name: 'LibriVox', link: 'https://librivox.org/' }
    ],
    'Video Lectures': [
      { name: 'TED-Ed', link: 'https://ed.ted.com/' },
      { name: 'YouTube EDU', link: 'https://www.youtube.com/education' },
      { name: 'Academic Earth', link: 'https://academicearth.org/' },
      { name: 'Big Think', link: 'https://bigthink.com/' },
      { name: 'The Great Courses', link: 'https://www.thegreatcourses.com/' }
    ],
    'Podcasts': [
      { name: 'iTunes U', link: 'https://www.apple.com/education/itunes-u/' },
      { name: 'NPR Podcast Directory', link: 'https://www.npr.org/podcasts/' },
      { name: 'TED Talks Audio', link: 'https://www.ted.com/talks' },
      { name: 'Google Podcasts', link: 'https://podcasts.google.com/' },
      { name: 'Spotify Podcasts', link: 'https://www.spotify.com/us/podcasts/' }
    ],
    'Webinars': [
      { name: 'WebinarNinja', link: 'https://webinarninja.com/' },
      { name: 'GoToWebinar', link: 'https://www.gotomeeting.com/webinar' },
      { name: 'Zoom Webinars', link: 'https://zoom.us/webinar' },
      { name: 'Demio', link: 'https://demio.com/' },
      { name: 'WebEx', link: 'https://www.webex.com/webinars.html' }
    ],
    'MOOCs': [
      { name: 'Class Central', link: 'https://www.classcentral.com/' },
      { name: 'MOOC List', link: 'https://www.mooc-list.com/' },
      { name: 'Open Education Consortium', link: 'https://www.oeconsortium.org/' },
      { name: 'MOOC.org', link: 'https://www.mooc.org/' },
      { name: 'Courseroot', link: 'https://courseroot.com/' }
    ],
    'Learning Notes': [
      { name: 'Evernote', link: 'https://www.evernote.com/' },
      { name: 'OneNote', link: 'https://www.onenote.com/' },
      { name: 'Notion', link: 'https://www.notion.so/' },
      { name: 'Bear', link: 'https://bear.app/' },
      { name: 'Zotero', link: 'https://www.zotero.org/' }
    ],
    'Interactive Simulations': [
      { name: 'PhET Interactive Simulations', link: 'https://phet.colorado.edu/' },
      { name: 'ExploreLearning Gizmos', link: 'https://www.explorelearning.com/' },
      { name: 'Ptable', link: 'https://ptable.com/' },
      { name: 'ChemCollective', link: 'http://chemcollective.org/' },
      { name: 'BioDigital Human', link: 'https://www.biodigital.com/' }
    ],
    'Online Forums and Communities': [
      { name: 'Stack Overflow', link: 'https://stackoverflow.com/' },
      { name: 'GitHub Discussions', link: 'https://github.com/features/discussions' },
      { name: 'Reddit', link: 'https://www.reddit.com/' },
      { name: 'Quora', link: 'https://www.quora.com/' },
      { name: 'Hacker News', link: 'https://news.ycombinator.com/' }
    ],
    'Educational Apps': [
      { name: 'Duolingo', link: 'https://www.duolingo.com/' },
      { name: 'Khan Academy', link: 'https://www.khanacademy.org/' },
      { name: 'Quizlet', link: 'https://quizlet.com/' },
      { name: 'Memrise', link: 'https://www.memrise.com/' },
      { name: 'Photomath', link: 'https://www.photomath.app/' }
    ],
    'Worksheets and Practice Exercises': [
      { name: 'WorksheetWorks', link: 'https://www.worksheetworks.com/' },
      { name: 'Math-Aids', link: 'https://www.math-aids.com/' },
      { name: 'Super Teacher Worksheets', link: 'https://www.superteacherworksheets.com/' },
      { name: 'EnglishForEveryone.org', link: 'https://www.englishforeveryone.org/' },
      { name: 'BusyTeacher', link: 'https://busyteacher.org/' }
    ],
    'Open Access Journals': [
      { name: 'Directory of Open Access Journals (DOAJ)', link: 'https://doaj.org/' },
      { name: 'PubMed Central (PMC)', link: 'https://www.ncbi.nlm.nih.gov/pmc/' },
      { name: 'ScienceDirect Open Access', link: 'https://www.sciencedirect.com/' },
      { name: 'PLOS (Public Library of Science)', link: 'https://www.plos.org/' },
      { name: 'Springer Open', link: 'https://www.springeropen.com/' }
    ],
    'Study Guides': [
      { name: 'CliffsNotes', link: 'https://www.cliffsnotes.com/' },
      { name: 'SparkNotes', link: 'https://www.sparknotes.com/' },
      { name: 'Shmoop', link: 'https://www.shmoop.com/' },
      { name: 'GradeSaver', link: 'https://www.gradesaver.com/' },
      { name: 'BrightHub Education', link: 'https://www.brighthubeducation.com/' }
    ],
    'Flashcards': [
      { name: 'Quizlet', link: 'https://quizlet.com/' },
      { name: 'StudyBlue', link: 'https://www.studyblue.com/' },
      { name: 'Brainscape', link: 'https://www.brainscape.com/' },
      { name: 'Anki', link: 'https://apps.ankiweb.net/' },
      { name: 'Cram.com', link: 'https://www.cram.com/' }
    ],
    'Infographics': [
      { name: 'Visual.ly', link: 'https://visual.ly/' },
      { name: 'Infogram', link: 'https://infogram.com/' },
      { name: 'Venngage', link: 'https://www.venngage.com/' },
      { name: 'Piktochart', link: 'https://piktochart.com/' },
      { name: 'Canva', link: 'https://www.canva.com/' }
    ],
    'Virtual Labs': [
      { name: 'PhET Interactive Simulations', link: 'https://phet.colorado.edu/' },
      { name: 'Labster', link: 'https://www.labster.com/' },
      { name: 'ChemCollective', link: 'http://chemcollective.org/' },
      { name: 'BioDigital Human', link: 'https://www.biodigital.com/' },
      { name: 'LabXchange', link: 'https://www.labxchange.org/' }
    ],
    'Open Textbooks': [
      { name: 'OpenStax', link: 'https://openstax.org/' },
      { name: 'Open Textbook Library', link: 'https://open.umn.edu/opentextbooks/' },
      { name: 'BCcampus OpenEd', link: 'https://open.bccampus.ca/find-open-textbooks/' },
      { name: 'Open Book Publishers', link: 'https://www.openbookpublishers.com/' },
      { name: 'Lumen Learning', link: 'https://courses.lumenlearning.com/' }
    ],
    'Educational Blogs': [
      { name: 'Edutopia', link: 'https://www.edutopia.org/' },
      { name: 'TeachThought', link: 'https://www.teachthought.com/' },
      { name: 'Cult of Pedagogy', link: 'https://www.cultofpedagogy.com/' },
      { name: 'The Learning Network (NY Times)', link: 'https://www.nytimes.com/section/learning' },
      { name: 'Education Week', link: 'https://www.edweek.org/' }
    ],
    'Coding Platforms': [
      { name: 'GitHub', link: 'https://github.com/' },
      { name: 'Codecademy', link: 'https://www.codecademy.com/' },
      { name: 'HackerRank', link: 'https://www.hackerrank.com/' },
      { name: 'LeetCode', link: 'https://leetcode.com/' },
      { name: 'Codewars', link: 'https://www.codewars.com/' }
    ],
    'Language Learning Resources': [
      { name: 'Duolingo', link: 'https://www.duolingo.com/' },
      { name: 'Memrise', link: 'https://www.memrise.com/' },
      { name: 'Babbel', link: 'https://www.babbel.com/' },
      { name: 'Rosetta Stone', link: 'https://www.rosettastone.com/' },
      { name: 'FluentU', link: 'https://www.fluentu.com/' }
    ]
  }
};

// Login functionality
function showLoginPage() {
  hideAllPages();
  document.getElementById('loginPage').classList.remove('hidden');
}

function loginUser(event) {
  event.preventDefault();
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;

  if (name && email) {
    // Mock login success
    document.getElementById('userName').textContent = name;
    showHomePage();
  }
}

// Navigation functions
function showHomePage() {
  hideAllPages();
  document.getElementById('homePage').classList.remove('hidden');
}

function logout() {
  hideAllPages();
  document.getElementById('welcomePage').classList.remove('hidden');
}

function showOnlineMentors() {
  hideAllPages();
  document.getElementById('onlineMentorsPage').classList.remove('hidden');
}

function showFreeLearningMaterials() {
  hideAllPages();
  document.getElementById('freeLearningMaterialsPage').classList.remove('hidden');
}

function showCategory(parentCategory, category) {
  hideAllPages();
  document.getElementById('categoryTitle').textContent = category;
  const categoryLinks = document.getElementById('categoryLinks');
  categoryLinks.innerHTML = '';

  categories[parentCategory][category].forEach(link => {
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.textContent = link.name;
    a.href = link.link;
    a.target = '_blank';
    li.appendChild(a);
    categoryLinks.appendChild(li);
  });

  document.getElementById('categoryPage').classList.remove('hidden');
}

function hideAllPages() {
  document.querySelectorAll('.page').forEach(page => {
    page.classList.add('hidden');
  });
}

// Initial setup
hideAllPages();
document.getElementById('welcomePage').classList.remove('hidden');
